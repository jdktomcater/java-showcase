﻿-- typayv2.merchant_balance_modification_record definition

CREATE TABLE `merchant_balance_modification_record` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `order_id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '订单ID',
  `merchant_order_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '商户订单ID',
  `merchant_id` int NOT NULL COMMENT '商户ID',
  `modification_type` tinyint NOT NULL DEFAULT '-1' COMMENT '余额变动类型，-1未知',
  `pre_balance` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT '交易前总余额',
  `post_balance` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT '交易后总余额',
  `pre_available_balance` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT '交易前可用余额',
  `post_available_balance` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT '交易后可用余额',
  `pre_frozen_balance` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT '交易前冻结余额',
  `post_frozen_balance` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT '交易后冻结余额',
  `remark` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '余额变动说明',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `node_id` int DEFAULT '1' COMMENT '节点ID',
  PRIMARY KEY (`id`) COMMENT '商户余额变动记录表',
  UNIQUE KEY `uniq_orderId_modType` (`order_id`,`modification_type`),
  KEY `idx_merchantid` (`merchant_id`),
  KEY `idx_merchant_order_id` (`merchant_order_id`),
  KEY `idx_date` (`created_at`,`updated_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1498564242227919937 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='商户余额变动记录表';


-- typayv2.merchant_order_amount_config definition

CREATE TABLE `merchant_order_amount_config` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `merchant_id` int NOT NULL DEFAULT '-1' COMMENT '商户ID',
  `min_amount` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT '最小金额',
  `max_amount` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT '最大金额',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`) COMMENT '商户接单金额配置表',
  UNIQUE KEY `uniq_merchant` (`merchant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1000500 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='商户接单金额配置表';


-- typayv2.sn_information definition

CREATE TABLE `sn_information` (
  `sn_number` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'SN号',
  `sn_info` varchar(2048) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'SN加密信息',
  `node_id` int NOT NULL DEFAULT '2' COMMENT '数据来源,1天下开发,2天下测试',
  PRIMARY KEY (`sn_number`) COMMENT 'sn信息表'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='sn信息表';


-- typayv2.t_agent_account_record definition

CREATE TABLE `t_agent_account_record` (
  `id` bigint unsigned NOT NULL COMMENT '主键',
  `agent_id` bigint NOT NULL COMMENT '代理ID',
  `merchant_id` bigint NOT NULL COMMENT '商户ID',
  `order_id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '订单ID',
  `pay_amount` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT '下单金额',
  `paid_amount` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT '实际金额',
  `supplier_charge` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT '商户服务费',
  `agent_charge` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT '订单佣金',
  `pre_agent_charge` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT '交易前佣金余额',
  `post_agent_charge` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT '交易后佣金余额',
  `node_id` int NOT NULL DEFAULT '2' COMMENT '节点ID',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `trans_type` tinyint NOT NULL DEFAULT '-1' COMMENT '交易类型',
  `merchant_order_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '商户订单号',
  `remark` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '备注',
  PRIMARY KEY (`id`) COMMENT '佣金收益记录表',
  KEY `idx_agentid` (`agent_id`),
  KEY `idx_create_at` (`created_at`),
  KEY `idx_indexOrderId` (`order_id`),
  KEY `idx_merchantid_createdat` (`merchant_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='佣金收益记录表';


-- typayv2.t_agent_bankcard_review definition

CREATE TABLE `t_agent_bankcard_review` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `agent_id` bigint NOT NULL DEFAULT '0' COMMENT '代理id',
  `supplierbranchid` int NOT NULL DEFAULT '0' COMMENT '财务分支',
  `review_status` int NOT NULL DEFAULT '0' COMMENT '审核状态 0:申请中，1:通过，2:拒绝',
  `applicant_id` bigint NOT NULL DEFAULT '0' COMMENT '申请人id',
  `applicant_name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '申请人名称',
  `reviewer_id` bigint NOT NULL DEFAULT '0' COMMENT '审核人id',
  `reviewer` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '审核人名称',
  `befor_worktype` int NOT NULL DEFAULT '0' COMMENT '1:收款,2:出款,3:中转,4:下发,5:手动出款,6:风云出款,7:风云入款,8:结汇, 9:第三方,10:第四方,11:技术支持,12:U盾',
  `after_worktype` int NOT NULL DEFAULT '0' COMMENT '1:收款,2:出款,3:中转,4:下发,5:手动出款,6:风云出款,7:风云入款,8:结汇, 9:第三方,10:第四方,11:技术支持,12:U盾',
  `review_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '审核时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '申请时间',
  `bankcard_id` bigint NOT NULL DEFAULT '0' COMMENT '银行卡id',
  `node_id` int NOT NULL DEFAULT '2' COMMENT '数据来源,1天下开发,2天下测试',
  PRIMARY KEY (`id`) COMMENT '代理银行卡审核表'
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='代理银行卡审核表';


-- typayv2.t_agent_charge_verify definition

CREATE TABLE `t_agent_charge_verify` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `agent_id` int NOT NULL DEFAULT '0' COMMENT '代理ID',
  `agent_name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '代理名称',
  `apply_no` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '申请编号',
  `type` tinyint NOT NULL DEFAULT '1' COMMENT '调整收益类型 1:可提现收益;2:回U收益;3:可提现收益/回U收益',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态 0-申请中, 1-申请通过, 2-申请拒绝',
  `cur_charge_before` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT '调整前可提现收益',
  `cur_charge_after` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT '调整后可提现收益',
  `margin_charge_before` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT '调整前回U收益',
  `margin_charge_after` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT '调整后回U收益',
  `node_id` tinyint NOT NULL DEFAULT '1' COMMENT '数据来源,1:TWTX;2:JianTX;3:JPTX',
  `create_by` int NOT NULL DEFAULT '0' COMMENT '申请人',
  `update_by` int NOT NULL DEFAULT '0' COMMENT '审核人',
  `remark` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '审批备注',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `adjust_remark` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '调整备注',
  PRIMARY KEY (`id`) COMMENT '代理收益审核表',
  UNIQUE KEY `uniq_apply_no` (`apply_no`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=1000265 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='代理收益审核表';


-- typayv2.t_agent_info definition

CREATE TABLE `t_agent_info` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `agent_name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '代理名称',
  `agent_type` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '代理类型，01：agent，02：recommend',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态，1启用 0停用',
  `supplier_branch_id` int NOT NULL DEFAULT '0' COMMENT '财务分支',
  `charge` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT '总收益',
  `cur_charge` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT '当前收益',
  `margin_charge` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT '回款收益',
  `frozen_charge` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT '冻结佣金',
  `node_id` int NOT NULL DEFAULT '2' COMMENT '节点ID',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`) COMMENT '代理信息表'
) ENGINE=InnoDB AUTO_INCREMENT=1200449 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='代理信息表';


-- typayv2.t_agent_member_config definition

CREATE TABLE `t_agent_member_config` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `member_id` int NOT NULL COMMENT '成员ID',
  `member_type` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '成员类型, 00: merchant, 01:agent, 02:recommend',
  `deposit_parent_rebate` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT '上级回U费率差',
  `deposit_plat_rebate` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT '平台回U费率差',
  `parent_type` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '上级成员类型, 00: merchant, 01:agent, 02:recommend',
  `parent_id` int NOT NULL DEFAULT '-1' COMMENT '上级成员ID, -1:平台',
  `visitable` tinyint NOT NULL DEFAULT '0' COMMENT '对间接上级可见',
  `node_id` int NOT NULL DEFAULT '2' COMMENT '节点ID',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `deposit_fixed_rebate` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT '商户固定汇率',
  `exchange_name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '交易所：binance, okex',
  `withdraw_fixed_rebate` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT '商户提款固定汇率',
  `merchant_initial_rebate` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT '商户开户汇率',
  PRIMARY KEY (`id`) COMMENT '代理上下级配置表',
  UNIQUE KEY `uniq_member_id_type` (`member_id`,`member_type`),
  KEY `idx_member_type_parent_id_visitable` (`member_type`,`parent_id`,`visitable`)
) ENGINE=InnoDB AUTO_INCREMENT=1004958 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='代理上下级配置表';


-- typayv2.t_agent_pay_type_rate definition

CREATE TABLE `t_agent_pay_type_rate` (
  `id` bigint unsigned NOT NULL COMMENT '主键',
  `agent_id` bigint NOT NULL COMMENT '代理ID',
  `merchant_id` bigint NOT NULL COMMENT '商户ID',
  `pay_type` int NOT NULL DEFAULT '0' COMMENT '支付方式',
  `agency_deposit_rate` decimal(5,4) NOT NULL DEFAULT '0.0000' COMMENT '代理返佣收款费率',
  `agency_withdraw_rate` decimal(5,4) NOT NULL DEFAULT '0.0000' COMMENT '代理返佣出款费率',
  `agency_withdraw_fixed_cost` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT '代理出款固定费率',
  `member_recharge_rate` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT '下级回U费率',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '1：启用，0:停用，-1:软删除',
  `remark` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '备注',
  `node_id` int NOT NULL DEFAULT '2' COMMENT '节点ID',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`) COMMENT '代理费率配置表',
  UNIQUE KEY `uniq_pay_type_merchant_agent` (`pay_type`,`merchant_id`,`agent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='代理费率配置表';


-- typayv2.t_agentbankcard definition

CREATE TABLE `t_agentbankcard` (
  `bankid` bigint NOT NULL COMMENT '银行卡id',
  `supplierbranchid` int NOT NULL DEFAULT '-1' COMMENT '分部id',
  `banknum` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '银行卡号码',
  `bankcode` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '银行卡编码',
  `banktype` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '银行卡类型代码',
  `address` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '开户地址',
  `depositaddress` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '充值地址',
  `ownername` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '开户人',
  `ownerphone` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '开户人手机预留号码',
  `owneridentity` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '开户人身份证',
  `worktype` int NOT NULL DEFAULT '-1' COMMENT '工作模式1:收款,2:付款',
  `balance` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '余额',
  `status` int NOT NULL DEFAULT '1' COMMENT '1：启用，0:停用，-1:软删除,-2:预启用, -3:交易限额停用 ,-4:余额超额停用,-5:交易笔数超额停用,-6:无转入转出停用,-7异常，-8临时停用，100：在线',
  `remark` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '备注',
  `createtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `lastupdatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `cardindex` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '银行卡index',
  `createby` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '创建人',
  `updatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `password` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '提款密码',
  `agent_id` bigint NOT NULL DEFAULT '0' COMMENT '卡商代理ID',
  `agent_code` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '代理编码',
  `node_id` int NOT NULL DEFAULT '2' COMMENT '数据来源,1天下开发,2天下测试',
  PRIMARY KEY (`bankid`) COMMENT '代理银行卡表',
  UNIQUE KEY `uniq_bankcode` (`bankcode`),
  UNIQUE KEY `uniq_banknum` (`banknum`,`bankcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='代理银行卡表';


-- typayv2.t_agentcreditorder definition

CREATE TABLE `t_agentcreditorder` (
  `orderindex` bigint NOT NULL AUTO_INCREMENT COMMENT '索引',
  `orderid` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT '订单号',
  `supplierbranchid` int NOT NULL DEFAULT '0' COMMENT '分部id',
  `paytype` int NOT NULL DEFAULT '0' COMMENT '充值方式,1:网银转账2:快捷支付3:银联支付4:微信5:支付宝6:qq钱包7:京东支付8:云闪付',
  `payamount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '提款金额',
  `paidamount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '实现到帐金额',
  `paidchannelfee` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '渠道手续费',
  `supplierpaidchannelfee` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '财务分支渠道费用',
  `notifyurl` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '商户用于接收订单通知的地址',
  `returnurl` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '订单提交后立即返回的商户页面地址',
  `bankcode` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '银行卡简码',
  `md5orderid` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'md5签名',
  `paychannelid` int NOT NULL DEFAULT '0' COMMENT '处理该订单的充值渠道',
  `banknum` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '处理该订单的银行卡',
  `bankaccount` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '处理该订单的银行卡简称',
  `orderstatus` int NOT NULL DEFAULT '0' COMMENT '订单状态0:创建，默认值;1：处理中;2:清算中;3:正常支付关闭;4：手工确认订单已完成关闭; 5:超时,6:超时关闭；7:取消关闭',
  `orderpaidstatuschangetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '订单状态最后修改时间',
  `ordernotifystatus` int NOT NULL DEFAULT '0' COMMENT '订单通知状态',
  `ordernotifytime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '订单通知状态最后修改时间',
  `remark` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '附言',
  `name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '名称',
  `createtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `lastupdatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `agent_id` bigint NOT NULL DEFAULT '0' COMMENT '卡商代理ID',
  `order_type` int NOT NULL DEFAULT '0' COMMENT '1为信用订单，2为转额度订单',
  `agent_code` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '代理编码',
  `node_id` int NOT NULL DEFAULT '2' COMMENT '数据来源,1天下开发,2天下测试',
  PRIMARY KEY (`orderindex`) COMMENT '代理额度转换,信用订单',
  KEY `createtime_index` (`createtime`),
  KEY `name_index` (`name`),
  KEY `name_remark_index` (`remark`,`name`),
  KEY `orderid_idx` (`orderid`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='代理额度转换,信用订单';


-- typayv2.t_agentdepositorder definition

CREATE TABLE `t_agentdepositorder` (
  `orderindex` bigint NOT NULL AUTO_INCREMENT COMMENT '索引',
  `orderid` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT '订单号',
  `supplierbranchid` int NOT NULL DEFAULT '0' COMMENT '分部id',
  `paytype` int NOT NULL DEFAULT '0' COMMENT '充值方式,1:网银转账2:快捷支付3:银联支付4:微信5:支付宝6:qq钱包7:京东支付8:云闪付',
  `payamount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '提款金额',
  `paidamount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '实现到帐金额',
  `paidchannelfee` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '渠道手续费',
  `supplierpaidchannelfee` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '财务分支渠道费用',
  `notifyurl` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '商户用于接收订单通知的地址',
  `returnurl` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '订单提交后立即返回的商户页面地址',
  `bankcode` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '银行卡简码',
  `md5orderid` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'md5签名',
  `paychannelid` int NOT NULL DEFAULT '0' COMMENT '处理该订单的充值渠道',
  `banknum` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '处理该订单的银行卡',
  `bankaccount` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '处理该订单的银行卡简称',
  `orderstatus` int NOT NULL DEFAULT '0' COMMENT '订单状态0:创建，默认值;1：处理中;2:清算中;3:正常支付关闭;4：手工确认订单已完成关闭; 5:超时,6:超时关闭；7:取消关闭',
  `orderpaidstatuschangetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '订单状态最后修改时间',
  `ordernotifystatus` int NOT NULL DEFAULT '0' COMMENT '订单通知状态',
  `ordernotifytime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '订单通知状态最后修改时间',
  `remark` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '附言',
  `name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '名称',
  `createtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `lastupdatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `agent_code` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '代理编码',
  `approvePersonnel` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '审核人员',
  `approveRemark` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '审核备注',
  `approveTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '审核时间',
  `agent_id` int NOT NULL DEFAULT '0' COMMENT '代理Id',
  `node_id` int NOT NULL DEFAULT '2' COMMENT '数据来源,1天下开发,2天下测试',
  PRIMARY KEY (`orderindex`) COMMENT '代理银行卡充值订单',
  KEY `createtime_index` (`createtime`),
  KEY `name_index` (`name`),
  KEY `name_remark_index` (`remark`,`name`),
  KEY `orderid_idx` (`orderid`)
) ENGINE=InnoDB AUTO_INCREMENT=1355558679864279041 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='代理银行卡充值订单';


-- typayv2.t_agentwithdraworder definition

CREATE TABLE `t_agentwithdraworder` (
  `orderindex` bigint NOT NULL COMMENT '订单索引',
  `orderid` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '订单id',
  `ordernotifytime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '订单通知时间',
  `supplierbranchid` int NOT NULL DEFAULT '-1' COMMENT '财务分部id',
  `paytype` int NOT NULL DEFAULT '-1' COMMENT '付款方式,1：银行卡，2：第三方，3：其他方式',
  `payamount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '提款金额',
  `paidamount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '实现到帐',
  `notifyurl` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '通知地址',
  `returnurl` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '回调地址',
  `paychannelid` int NOT NULL DEFAULT '0' COMMENT '处理该订单的充值渠道',
  `bankaccount` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '银行帐号',
  `orderstatus` int NOT NULL DEFAULT '0' COMMENT '订单状态',
  `ordernotifystatus` int NOT NULL DEFAULT '0' COMMENT '订单通知状态',
  `remark` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '备注',
  `bankcode` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '银行卡简码',
  `banknum` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '银行卡号',
  `bankaddress` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '银行卡地址',
  `bankowner` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '银行卡持有者',
  `md5orderid` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'md5订单加密信息',
  `digest` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'digest',
  `ordertype` int NOT NULL DEFAULT '0' COMMENT '订单类型',
  `createtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `agent_code` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '代理编码',
  `lastupdatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `agent_id` bigint NOT NULL DEFAULT '0' COMMENT '代理id',
  `agent_name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '代理名称',
  `approvePersonnel` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '审核人员',
  `approveRemark` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '审核备注',
  `approveTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '审核时间',
  `node_id` int NOT NULL DEFAULT '2' COMMENT '数据来源,1天下开发,2天下测试',
  PRIMARY KEY (`orderindex`) COMMENT '卡商提款订单',
  UNIQUE KEY `uniq_orderid` (`orderid`),
  KEY `create_ordernotify_ordertype` (`ordertype`,`ordernotifystatus`,`createtime`),
  KEY `createtime_index` (`createtime`),
  KEY `digest_index` (`digest`),
  KEY `orderid_idx` (`orderid`),
  KEY `supplierbranchid_index` (`supplierbranchid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='卡商提款订单';


-- typayv2.t_b2binternaltransorder definition

CREATE TABLE `t_b2binternaltransorder` (
  `OrderIndex` bigint NOT NULL COMMENT '订单索引',
  `OrderID` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SupplierBranchID` int DEFAULT NULL COMMENT '分部ID',
  `OutputBankID` int DEFAULT NULL COMMENT '转出银行卡ID',
  `OutputBankAccount` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `InputBankID` int DEFAULT NULL COMMENT '转入银行卡ID',
  `InputBankNum` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `InputBankOnwer` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `InputBankAddress` varchar(270) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '转入银行卡开户地址',
  `TradeAmount` decimal(10,2) DEFAULT NULL,
  `Status` int DEFAULT '0' COMMENT '订单状态0:创建，默认值;1：处理中;2:清算中;3:正常支付关闭;4：手工确认订单已完成关闭; 5:超时,6:超时关闭；7:取消关闭',
  `BankCode` varchar(8) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '银行卡类型代码',
  `OrderType` int DEFAULT NULL COMMENT '订单类型,1:超额内转订单，2低额内转订单，3，充值测试转账订单,4提款测试转账订单,5卡异常转出金额,100父订单',
  `Remark` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CreateTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `LastUpDateTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `EncryptOutputBankAccount` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '转出银行卡简码',
  `EncryptInputBankNum` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '转入银行卡号码',
  `EncryptInputBankOnwer` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '转入姓名',
  `EncryptInputBankAddress` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '转入银行卡开户地址',
  `node_id` int NOT NULL DEFAULT '2' COMMENT '数据来源,1天下开发,2天下测试',
  PRIMARY KEY (`OrderIndex`),
  UNIQUE KEY `uniq_OrderID` (`OrderID`),
  KEY `idx_createtime` (`CreateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- typayv2.t_bank_sms_template definition

CREATE TABLE `t_bank_sms_template` (
  `id` bigint NOT NULL COMMENT '表ID',
  `sms_phone_no` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '银行短信号码，分号分隔',
  `sms_template` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '短信模板',
  `bank_code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '银行编码',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `version` int NOT NULL DEFAULT '0' COMMENT '版本号',
  `operator` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '操作人',
  `sms_content` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '短信内容，分号分隔',
  `sms_status` tinyint NOT NULL DEFAULT '0' COMMENT '状态 0禁用 1启用',
  PRIMARY KEY (`id`) COMMENT '银行短信模板表',
  UNIQUE KEY `uniq_bank_code` (`bank_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='银行短信模板表';


-- typayv2.t_bank_type_strict definition

CREATE TABLE `t_bank_type_strict` (
  `BankTypeID` int NOT NULL AUTO_INCREMENT COMMENT '银行卡类型ID',
  `BankTypeName` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '银行卡类型名称',
  `BankTypeCode` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '银行卡类型代码',
  `ReMark` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CreateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `LastUpDateTime` datetime DEFAULT NULL,
  `CurrencyType` int DEFAULT '0' COMMENT '币种类型  0 RMB  1虚拟币',
  `node_id` int NOT NULL DEFAULT '2' COMMENT '数据来源,1天下开发,2天下测试',
  PRIMARY KEY (`BankTypeID`) COMMENT '银行卡类型表',
  UNIQUE KEY `BankTypeCode_UNIQUE` (`BankTypeCode`),
  UNIQUE KEY `BankTypeName_UNIQUE` (`BankTypeName`)
) ENGINE=InnoDB AUTO_INCREMENT=349 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='银行卡类型表';


-- typayv2.t_bankaccountrecord definition

CREATE TABLE `t_bankaccountrecord` (
  `BankID` int NOT NULL COMMENT '银行卡ID',
  `TransID` bigint NOT NULL COMMENT '交易流水ID',
  `OrderIndex` bigint DEFAULT NULL COMMENT '平台订单号索引',
  `MerchantOrderIndex` bigint DEFAULT NULL COMMENT '商户订单号索引',
  `OrderID` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `MerchantOrderID` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TransType` int DEFAULT NULL COMMENT '交易方式,0：收款，1：付款 ,2:内转',
  `TransAmount` decimal(10,2) DEFAULT NULL,
  `PaidAmount` decimal(10,2) DEFAULT NULL,
  `PayChannelFee` decimal(10,2) DEFAULT NULL,
  `SupplierPaidChannelFee` decimal(20,2) DEFAULT NULL COMMENT '商户手续费',
  `PreBalance` decimal(10,2) DEFAULT NULL,
  `Balance` decimal(10,2) DEFAULT NULL,
  `CreateTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `SupplierBranchID` int NOT NULL,
  `node_id` int NOT NULL DEFAULT '2' COMMENT '数据来源,1天下开发,2天下测试',
  PRIMARY KEY (`BankID`,`TransID`) COMMENT '银行卡账变表',
  KEY `idx_MerchantOrderID` (`MerchantOrderID`),
  KEY `idx_transid_orderid` (`TransID`,`OrderID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='银行卡账变表';


-- typayv2.t_bankcard definition

CREATE TABLE `t_bankcard` (
  `BankID` int NOT NULL COMMENT '银行卡ID',
  `SupplierBranchID` int DEFAULT NULL COMMENT '分部ID',
  `BankNum` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '银行卡号码',
  `LoginAccount` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '银行卡网银登录账号',
  `BankCode` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '银行卡编码',
  `PoolID` int DEFAULT NULL COMMENT '所属银行卡池',
  `Auth` int DEFAULT NULL COMMENT '查看员',
  `BankType` varchar(8) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '银行卡类型代码',
  `Address` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '开户地址',
  `DepositAddress` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '充值地址',
  `OwnerName` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '开户人',
  `OwnerPhone` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '开户人手机预留号码',
  `OwnerIdentity` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '开户人身份证',
  `WorkType` int DEFAULT NULL COMMENT '工作模式1:收款,2:付款',
  `Balance` decimal(10,2) DEFAULT NULL COMMENT '余额',
  `MaxBalance` decimal(10,2) DEFAULT NULL COMMENT '最大余额，超过则要转到其他卡,恢复到InitBalance',
  `MinBalance` decimal(10,2) DEFAULT NULL COMMENT '最小额度，少于则要转入额度到InitBalance',
  `InitBalance` decimal(10,2) DEFAULT NULL COMMENT '初始余额',
  `SumAmountPerDayTrans` decimal(10,2) DEFAULT NULL COMMENT '每日交易总额限额,默认0不限制',
  `SumTimesPerDayTrans` decimal(10,2) DEFAULT NULL COMMENT '每日转出笔数限额,默认0不限制',
  `MinAmountPerTrans` decimal(10,2) DEFAULT NULL COMMENT '每笔交易最小额度,默认0不限制',
  `WMinAmountPerTrans` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '出款每笔交易最小额度,默认0不限制，作用于提款和内转转出',
  `MaxAmountPerTrans` decimal(10,2) DEFAULT NULL COMMENT '每笔交易最大额度,默认0不限制',
  `WMaxAmountPerTrans` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '每笔交易最大额度,默认0不限制, 作用于提款和内转转出',
  `AliSumTimesPerDayTrans` decimal(10,2) DEFAULT NULL COMMENT '支付宝每日转出笔数限额,默认0不限制',
  `AliSumAmountPerDayTrans` decimal(10,2) DEFAULT NULL COMMENT '支付宝每日交易总额限额,默认0不限制',
  `AliMinAmountPerTrans` decimal(10,2) DEFAULT NULL COMMENT '支付宝每笔交易最小额度,默认0不限制',
  `AliMaxAmountPerTrans` decimal(10,2) DEFAULT NULL COMMENT '支付宝每笔交易最大额度,默认0不限制',
  `Status` int DEFAULT NULL COMMENT '1：启用，0:停用，-1:软删除,-2:预启用, -3:交易限额停用 ,-4:余额超额停用,-5:交易笔数超额停用,-6:无转入转出停用,-7异常，-8临时停用，100：在线',
  `Comments` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '人工备注',
  `ReMark` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '系统自动备注',
  `Version` int DEFAULT NULL,
  `ULoginPWD` varchar(516) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'U盾登录密码',
  `UkeyPWD` varchar(516) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'U盾密码',
  `LoginPWD` varchar(516) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '登录密码，加密',
  `PayPWD` varchar(516) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '支付密码，加密',
  `UCode` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '子账号',
  `TagID` int DEFAULT NULL COMMENT '银行卡标签',
  `PhoneID` int DEFAULT NULL COMMENT '手机ID',
  `LastLoginClientName` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '最后一次登录的自动机',
  `CreateTime` datetime DEFAULT NULL,
  `LastUpDateTime` datetime DEFAULT NULL,
  `CardIndex` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '银行卡Index',
  `authes` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '保存多个权限名称',
  `CreateBy` int NOT NULL DEFAULT '0' COMMENT '创建人',
  `updateTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `updateBy` int NOT NULL DEFAULT '0' COMMENT '修改人',
  `surplier_type` int NOT NULL DEFAULT '0' COMMENT '卡类型（0为天下卡，1为卡商卡，默认0）',
  `agent_id` int unsigned NOT NULL DEFAULT '0' COMMENT '卡商代理ID',
  `qrcode` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '二维码url',
  `EncryptBankNum` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '银行卡号码',
  `EncryptLoginAccount` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '银行卡网银登录账号',
  `EncryptBankCode` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '银行卡编码',
  `EncryptAddress` varchar(360) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '开户地址',
  `EncryptDepositAddress` varchar(270) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '充值地址',
  `EncryptOwnerName` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '开户人',
  `EncryptOwnerPhone` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '开户人手机预留号码',
  `EncryptOwnerIdentity` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '开户人身份证',
  `EncryptUcode` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '子账号',
  `node_id` int NOT NULL DEFAULT '2' COMMENT '数据来源,1天下开发,2天下测试',
  `IsSmsMatch` tinyint NOT NULL DEFAULT '0' COMMENT '是否短信匹配 0否 1是',
  `FromCashier` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否来自卡商 0否 1是',
  `CashierId` bigint NOT NULL DEFAULT '0' COMMENT '卡商ID',
  `ReviewedTime` datetime DEFAULT NULL COMMENT '审核时间',
  `multiSwitch` int DEFAULT NULL COMMENT '并发开关:0关闭;1开启',
  PRIMARY KEY (`BankID`) COMMENT '银行卡表'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='银行卡表';


-- typayv2.t_bankcard_agent definition

CREATE TABLE `t_bankcard_agent` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '代理ID',
  `supplier_branch_id` int NOT NULL DEFAULT '0' COMMENT '财务分支',
  `agent_code` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '代理编码',
  `agent_name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '代理名称',
  `parent_agent_code` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '父级代理编码',
  `balance` decimal(20,2) NOT NULL DEFAULT '0.00' COMMENT '总余额',
  `credit_balance` decimal(20,2) NOT NULL DEFAULT '0.00' COMMENT '信用余额',
  `available_balance` decimal(20,2) NOT NULL DEFAULT '0.00' COMMENT '可用余额',
  `fronzen_balance` decimal(20,2) NOT NULL DEFAULT '0.00' COMMENT '冻结余额',
  `ExtraBalance` decimal(20,2) NOT NULL DEFAULT '0.00' COMMENT '额外支出余额',
  `ratio` decimal(20,2) NOT NULL DEFAULT '0.00' COMMENT '费率',
  `profit_balance` decimal(20,2) NOT NULL DEFAULT '0.00' COMMENT '收益',
  `status` int NOT NULL DEFAULT '1' COMMENT '1：启用，0:停用，-1:软删除',
  `remark` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '备注',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `last_update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `version` bigint NOT NULL DEFAULT '0' COMMENT '版本',
  `user_id` bigint NOT NULL DEFAULT '-1' COMMENT '卡商代理登录账号',
  `agent_level` int NOT NULL DEFAULT '-1' COMMENT '代理层级：0为卡商（总代），1为一级代理',
  `createby` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '创建人',
  `parent_agent_id` bigint NOT NULL DEFAULT '0' COMMENT '父卡商代理ID',
  `pay_code` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '支付密码（提款密码）',
  `parent_supplier_branch_id` int NOT NULL DEFAULT '0' COMMENT '父级财务分支',
  `node_id` int NOT NULL DEFAULT '2' COMMENT '数据来源,1天下开发,2天下测试',
  PRIMARY KEY (`id`) COMMENT '卡商代理'
) ENGINE=InnoDB AUTO_INCREMENT=114 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='卡商代理';


-- typayv2.t_bankcard_agent_accountrecord definition

CREATE TABLE `t_bankcard_agent_accountrecord` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '记录ID',
  `agent_code` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '代理编码',
  `supplier_branch_id` int NOT NULL DEFAULT '0' COMMENT '财务分支',
  `order_id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '订单ID',
  `bank_id` int NOT NULL DEFAULT '0' COMMENT '银行卡ID',
  `trans_type` int NOT NULL DEFAULT '-1' COMMENT '交易方式,0：充值，1：提款，2 交押金，3 退押金 4 利润转押金',
  `trans_amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '交易金额',
  `paid_amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '实际交易金额',
  `balance` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '余额',
  `available_balance` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '可用余额',
  `frozen_balance` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '冻结余额',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `agent_id` bigint NOT NULL DEFAULT '0' COMMENT '卡商代理ID',
  `node_id` int NOT NULL DEFAULT '2' COMMENT '数据来源,1天下开发,2天下测试',
  PRIMARY KEY (`id`) COMMENT '卡商卡账变',
  KEY `idx_create_time_agent` (`create_time`,`agent_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='卡商卡账变';


-- typayv2.t_bankcard_agent_manual_record definition

CREATE TABLE `t_bankcard_agent_manual_record` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '平台订单索引',
  `supplier_branch_id` int NOT NULL DEFAULT '0' COMMENT '财务分支',
  `agent_id` bigint NOT NULL DEFAULT '0' COMMENT '卡商代理ID',
  `agent_code` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '代理编码',
  `type` int NOT NULL DEFAULT '-1' COMMENT '帐变类型,0：调整可用额度，1：调整额外支付余额',
  `reviseBalance` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '调整金额',
  `before_balance` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '调整前余额',
  `balance` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '余额',
  `before_available_balance` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '调整前可用余额',
  `available_balance` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '可用余额',
  `before_extra_balance` decimal(20,2) NOT NULL DEFAULT '0.00' COMMENT '调整前额外支出余额',
  `extra_balance` decimal(20,2) NOT NULL DEFAULT '0.00' COMMENT '额外支出余额',
  `frozen_balance` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '冻结余额',
  `remark` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '备注',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `node_id` int NOT NULL DEFAULT '2' COMMENT '数据来源,1天下开发,2天下测试',
  PRIMARY KEY (`id`) COMMENT '卡商卡手工账变表',
  KEY `idx_agent_code` (`agent_code`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='卡商卡手工账变表';


-- typayv2.t_bankcard_valid definition

CREATE TABLE `t_bankcard_valid` (
  `id` bigint NOT NULL COMMENT '银行卡ID',
  `bank_type` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '银行卡类型代码',
  `encrypt_bank_num` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '银行卡号码',
  `encrypt_owner_name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '开户人',
  `encrypt_address` varchar(360) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '开户地址',
  `approve_code` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '认证编码',
  `approve_desc` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '认证描述',
  `approve_order_no` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '认证订单号',
  `node_id` int NOT NULL DEFAULT '2' COMMENT '数据来源,1天下开发,2天下测试',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '新增时间',
  PRIMARY KEY (`id`) COMMENT '有效银行卡信息表',
  UNIQUE KEY `uniq_encrypt_bank_num` (`encrypt_bank_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='有效银行卡信息表';


-- typayv2.t_bankcardpool definition

CREATE TABLE `t_bankcardpool` (
  `BankPooID` int NOT NULL COMMENT '银行卡池ID',
  `SupplierBranchID` int DEFAULT NULL COMMENT '财务分部ID',
  `BankPoolName` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '银行卡池名称',
  `WorkType` int DEFAULT NULL,
  `Status` int DEFAULT NULL COMMENT '1：启用，0:停用，-1:软删除',
  `RoleType` int DEFAULT NULL COMMENT '0入款卡池 1出款卡池 2下发卡池 3其他卡池 4中转卡池',
  `InputPoolID` int DEFAULT NULL COMMENT '向本池转入资金的卡池',
  `OutputPoolID` int DEFAULT NULL COMMENT '从本池转出资金的卡池',
  `ReMark` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CreateTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `LastUpDateTime` datetime DEFAULT NULL,
  `OutPutTestPoolID` int DEFAULT NULL COMMENT '从本池转出资金的测试卡池',
  `OutputPoolIDs` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '从本池转出资金的卡池,多个逗号分隔',
  `surplier_type` int NOT NULL DEFAULT '0' COMMENT '卡类型（0为天下卡，1为卡商卡，默认0）',
  `MaxAmountPerTrans` decimal(8,2) NOT NULL DEFAULT '0.00' COMMENT '单笔交易最大限额',
  `MinAmountPerTrans` decimal(8,2) NOT NULL DEFAULT '0.00' COMMENT '单笔交易最小限额',
  `Node_ID` tinyint NOT NULL DEFAULT '2' COMMENT '数据来源,1天下开发,2天下测试',
  PRIMARY KEY (`BankPooID`) COMMENT '银行卡池'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='银行卡池';


-- typayv2.t_bankcardsummary definition

CREATE TABLE `t_bankcardsummary` (
  `BankID` int NOT NULL,
  `DepositAmount` decimal(10,2) NOT NULL,
  `HistoryDepositAmount` decimal(20,2) DEFAULT NULL,
  `WithdrawAmount` decimal(10,2) NOT NULL,
  `Calendar` date NOT NULL,
  `LastUpDateTime` datetime NOT NULL,
  `DepositTimes` int DEFAULT NULL,
  `WithdrawTimes` int DEFAULT NULL,
  `Version` bigint NOT NULL,
  `AliDepositTimes` int DEFAULT NULL COMMENT '支付宝日次数',
  `AliDepositAmount` decimal(10,2) DEFAULT NULL COMMENT '支付宝日存款',
  `node_id` int NOT NULL DEFAULT '2' COMMENT '数据来源,1天下开发,2天下测试',
  PRIMARY KEY (`BankID`,`Calendar`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- typayv2.t_bankclient_copy1 definition

CREATE TABLE `t_bankclient_copy1` (
  `ClientID` int NOT NULL AUTO_INCREMENT COMMENT '客户端ID,自增',
  `SupplierBranchID` int DEFAULT NULL,
  `BankType` varchar(8) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '客户端类型,1招行客户端CMB，2:建行客户端CCB ',
  `ClientName` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '客户端名称',
  `Status` int DEFAULT NULL COMMENT '服务状态，1：启用，0:停用，-1:软删除,100:上线，-100异常',
  `Identity` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '身份证码,登录时发送身份证码用于验证该客户端合法',
  `BankAccount` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '银行卡简码，当前绑定银行卡',
  `LogoutMsg` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ReMark` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CreateTime` datetime DEFAULT NULL,
  `LastUpDateTime` datetime DEFAULT NULL,
  `WorkType` int DEFAULT NULL COMMENT '工作类型：1收款,2:付款, 3收付款',
  `node_id` int NOT NULL DEFAULT '2' COMMENT '数据来源,1天下开发,2天下测试',
  PRIMARY KEY (`ClientID`) COMMENT '银行卡客户端'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='银行卡客户端';


-- typayv2.t_bankinchannel definition

CREATE TABLE `t_bankinchannel` (
  `BankID` int NOT NULL,
  `ChannelID` int NOT NULL,
  `node_id` int NOT NULL DEFAULT '2' COMMENT '数据来源,1天下开发,2天下测试',
  PRIMARY KEY (`BankID`,`ChannelID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- typayv2.t_bankinpool definition

CREATE TABLE `t_bankinpool` (
  `BankID` int NOT NULL,
  `PoolID` int NOT NULL,
  `node_id` int NOT NULL DEFAULT '2' COMMENT '数据来源,1天下开发,2天下测试',
  PRIMARY KEY (`BankID`,`PoolID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- typayv2.t_banktag definition

CREATE TABLE `t_banktag` (
  `TagID` int NOT NULL AUTO_INCREMENT COMMENT '标签ID',
  `SupplierBranchID` int DEFAULT NULL,
  `TagName` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '标签名称',
  `Remark` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  `node_id` int NOT NULL DEFAULT '2' COMMENT '数据来源,1天下开发,2天下测试',
  PRIMARY KEY (`TagID`) COMMENT '银行标签表'
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='银行标签表';


-- typayv2.t_banktrans definition

CREATE TABLE `t_banktrans` (
  `ID` bigint NOT NULL AUTO_INCREMENT COMMENT '流水ID',
  `SupplierBranchID` int DEFAULT NULL COMMENT '财务分部ID',
  `ClientID` int DEFAULT NULL COMMENT '客户端编号',
  `BankCode` varchar(8) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '银行类型代码',
  `BankAccount` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '银行简记码',
  `BankID` int DEFAULT NULL COMMENT '银行卡编号',
  `PayChannelID` int DEFAULT NULL COMMENT '渠道编号,内部卡转卡为0',
  `TransTime` datetime DEFAULT NULL COMMENT '交易时间',
  `TransFee` decimal(10,2) DEFAULT NULL COMMENT '手续费',
  `TransType` int DEFAULT NULL COMMENT '交易方式:0支出,1:收入',
  `TransAmount` decimal(10,2) DEFAULT NULL COMMENT '交易金额',
  `PreBalance` decimal(10,2) DEFAULT NULL COMMENT '交易前余额',
  `Balance` decimal(10,2) DEFAULT NULL COMMENT '当前余额',
  `Remark` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '附言',
  `Name` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '交易姓名',
  `TransAccount` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '交易银行卡',
  `ReadMark` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '加锁标记',
  `Status` int DEFAULT '0' COMMENT '处理状态，0：创建，1：处理中，2：已成功处理，3：超时移入异常收支',
  `CreateTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '发送时间',
  `PickTime` datetime DEFAULT NULL COMMENT '被抓取时间',
  `Md5Sign` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'md5后的唯一编码',
  `MerchantID` int DEFAULT NULL COMMENT '商户id',
  `MemberTransAccount` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '会员交易账号',
  `EncryptBankAccount` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '银行简记码',
  `EncryptName` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '交易姓名',
  `EncryptTransAccount` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '交易银行卡',
  `MerchantOrderID` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '商户订单号',
  `Operator` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '操作员登录名',
  `ReceiptID` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '回执单号',
  `node_id` int NOT NULL DEFAULT '2' COMMENT '数据来源,1天下开发,2天下测试',
  `DeviceType` tinyint(1) NOT NULL DEFAULT '0' COMMENT '设备类型 0PC自动机 1手机银行',
  `BankReplyCode` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '银行回传编码：唯一编码',
  PRIMARY KEY (`ID`) COMMENT '银行卡流水表',
  KEY `idx_BankAccount` (`BankAccount`),
  KEY `idx_BankReplyCode` (`BankReplyCode`),
  KEY `idx_Name` (`Name`),
  KEY `idx_CreateTime` (`CreateTime`),
  KEY `idx_TransAccount` (`TransAccount`),
  KEY `idx_STATUS` (`Status`),
  KEY `idx_TransType` (`TransType`),
  KEY `idx_TransAmount` (`TransAmount`)
) ENGINE=InnoDB AUTO_INCREMENT=1768916773971648650 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='银行卡流水表';


-- typayv2.t_banktype definition

CREATE TABLE `t_banktype` (
  `BankTypeID` int NOT NULL AUTO_INCREMENT COMMENT '银行卡类型ID',
  `BankTypeName` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '银行卡类型名称',
  `BankTypeCode` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '银行卡类型代码',
  `ReMark` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CreateTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `LastUpDateTime` datetime DEFAULT NULL,
  `currency_type` int NOT NULL DEFAULT '0' COMMENT '币种 0、人民币银行 1、虚拟币币种',
  `CurrencyType` int DEFAULT '0' COMMENT '币种类型  0 RMB  1虚拟币',
  `node_id` int NOT NULL DEFAULT '2' COMMENT '数据来源,1天下开发,2天下测试',
  PRIMARY KEY (`BankTypeID`) COMMENT '银行卡类型表',
  UNIQUE KEY `BankTypeCode_UNIQUE` (`BankTypeCode`),
  UNIQUE KEY `BankTypeName_UNIQUE` (`BankTypeName`)
) ENGINE=InnoDB AUTO_INCREMENT=1001996 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='银行卡类型表';


-- typayv2.t_buffer_order_record definition

CREATE TABLE `t_buffer_order_record` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `redis_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'redisKey',
  `member` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'sortset成员',
  `score` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'sortset成员分数',
  `order_status` tinyint NOT NULL DEFAULT '0' COMMENT '异常记录状态',
  `fail_num` int NOT NULL DEFAULT '1' COMMENT '写缓存失败次数',
  `crt_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '记录创建时间',
  `upt_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '记录更新时间',
  `node_id` int NOT NULL DEFAULT '2' COMMENT '数据来源,1天下开发,2天下测试',
  PRIMARY KEY (`id`) COMMENT '缓存异常记录表',
  KEY `idx_crt_time` (`crt_time`)
) ENGINE=InnoDB AUTO_INCREMENT=1000052 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='缓存异常记录表';


-- typayv2.t_business_withdraw_order definition

CREATE TABLE `t_business_withdraw_order` (
  `id` bigint unsigned NOT NULL COMMENT '主键',
  `supplier_branch_id` int NOT NULL DEFAULT '0' COMMENT '财务分支',
  `merchant_id` int DEFAULT NULL COMMENT '商户编号',
  `merchant_name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '商户名称',
  `order_id` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '订单号',
  `merchant_order_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商户订单号',
  `user_credit_level` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '用户层级，根据用户层级等级分配不同支付渠道;多个层级，使用‘,’分割，比如支持5_1,5_2层级，则是5_1,5_2',
  `user_level` int DEFAULT '-1' COMMENT '会员等级',
  `pay_type` int DEFAULT NULL COMMENT '付款方式,1：银行卡，2：第三方，3：其他方式',
  `pay_amount` decimal(18,4) DEFAULT '0.0000' COMMENT '订单金额',
  `paid_amount` decimal(18,4) DEFAULT '0.0000' COMMENT '实际金额',
  `supplier_paid_channel_fee` decimal(18,4) DEFAULT NULL COMMENT '渠道提供方手续费，比如需向三方通道付手续费，比如平均银行卡磨损费',
  `order_status` int DEFAULT '0' COMMENT '订单状态 0创建,1处理中,3成功,7失败',
  `order_paid_status_change_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '订单状态最后修改时间',
  `order_notify_status` int DEFAULT '0' COMMENT '订单通知状态 0未成功通知, 1已成功通知, 2通知超时异常',
  `order_type` int DEFAULT '0' COMMENT '订单类型 0会员提款, 1商户提款',
  `encrypt_bank_account` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商户银行卡简码',
  `encrypt_bank_owner` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '提款人',
  `encrypt_bank_num` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '银行卡号码',
  `encrypt_member_account` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '会员账号',
  `encrypt_bank_address` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '开户地址',
  `amount_type` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT 'CNY' COMMENT '金额类型 默认CNY 具体数值参考币种',
  `virtual_pay_amount` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT '虚拟币金额',
  `virtual_paid_amount` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT '虚拟币金额',
  `remark` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  `node_id` int NOT NULL DEFAULT '2' COMMENT '节点ID',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) COMMENT '商户前台-会员提现订单',
  UNIQUE KEY `uniq_merchant_order_id` (`merchant_order_id`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_order_paid_status_change_time` (`order_paid_status_change_time`),
  KEY `idx_merchant_order_id_pay_amount` (`merchant_order_id`,`pay_amount`),
  KEY `idx_supplier_branch_id` (`supplier_branch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='商户前台-会员提现订单';


-- typayv2.t_callback_domain definition

CREATE TABLE `t_callback_domain` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `cdn_name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'CDN厂商名',
  `domain_url` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '域名地址',
  `status` int NOT NULL DEFAULT '0' COMMENT '服务状态(-1:删除,0:停用,1:启用)',
  `remark` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '备注',
  `create_by` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '创建者',
  `update_by` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '修改者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '新增时间',
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `domain_type` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '域名类型（1：三方回调域名，2：平台反查域名，默认1）',
  `node_id` int NOT NULL DEFAULT '2' COMMENT '数据来源,1天下开发,2天下测试',
  PRIMARY KEY (`id`) COMMENT '回调域名'
) ENGINE=InnoDB AUTO_INCREMENT=1001624 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='回调域名';


-- typayv2.t_cashier_login_log definition

CREATE TABLE `t_cashier_login_log` (
  `id` bigint NOT NULL COMMENT 'ID',
  `login_name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '登录账号',
  `login_time` datetime NOT NULL COMMENT '登录时间',
  `ip_addr` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '登录IP地址',
  `login_location` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '登录地点',
  `msg` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '提示消息',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `supplier_branch_id` int NOT NULL DEFAULT '0' COMMENT '财务分部ID',
  `node_id` int NOT NULL DEFAULT '2' COMMENT '数据来源,1天下开发,2天下测试',
  PRIMARY KEY (`id`) COMMENT '卡商登录记录'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='卡商登录记录';


-- typayv2.t_cashier_user definition

CREATE TABLE `t_cashier_user` (
  `id` bigint NOT NULL COMMENT '主键',
  `user_name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '账号',
  `pass_word` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '密码',
  `user_status` tinyint NOT NULL DEFAULT '1' COMMENT '用户状态  1启用  0禁用',
  `del_flag` tinyint NOT NULL DEFAULT '0' COMMENT '删除标识 0正常 1删除',
  `login_ip` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '最后登陆IP',
  `login_date` datetime NOT NULL DEFAULT '1970-01-01 08:00:00' COMMENT '最后登陆时间',
  `create_by` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '创建人',
  `google_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '谷歌验证码',
  `remark` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '备注',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `supplier_branch_id` int NOT NULL DEFAULT '0' COMMENT '财务分支',
  `last_login_date` datetime NOT NULL DEFAULT '1970-01-01 08:00:00' COMMENT '上一次登录时间',
  `node_id` int NOT NULL DEFAULT '2' COMMENT '数据来源,1天下开发,2天下测试',
  PRIMARY KEY (`id`) COMMENT '卡商账号表',
  UNIQUE KEY `uniq_user_name` (`user_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='卡商账号表';