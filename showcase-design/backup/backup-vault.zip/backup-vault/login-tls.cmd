@echo off
setlocal

REM ======= 配置区 =======
set "VAULT_ADDR=https://txdev-vault.qwasn.com"
set "VAULT_CACERT=crt/vault-ca.crt"
set "VAULT_SKIP_VERIFY=true"
vault status
vault login -method=cert -client-cert=crt/client.crt -client-key=crt/client.key name=typayv2slave
REM ======================

