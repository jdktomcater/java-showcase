path "database/creds/htx-mathcup-pay-role-v0" {
  capabilities = ["read","update"]
}
path "database/creds/htx-mathcup-pay-slave-role-v0" {
  capabilities = ["read","update"]
}
path "database/creds/htx-mathcup-pay-role-admin-v0" {
  capabilities = ["read","update"]
}

path "sys/leases/renew" {
  capabilities = ["update"]
}

path "sys/leases/lookup" {
  capabilities = ["update"]
}

path "sys/leases/revoke" {
  capabilities = ["update"]
}

path "sys/leases/revoke-prefix/*" {
  capabilities = ["update"]
}

path "auth/token/lookup-self" {
  capabilities = ["read"]
}

path "auth/token/renew-self" {
  capabilities = ["update"]
}

path "sys/capabilities-self" {
  capabilities = ["update"]
}
