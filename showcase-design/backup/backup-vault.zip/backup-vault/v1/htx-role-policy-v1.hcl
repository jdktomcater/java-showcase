path "database/creds/htx-mathcup-pay-role-v1" {
  capabilities = ["read","update"]
}
path "database/creds/htx-mathcup-pay-slave-role-v1" {
  capabilities = ["read","update"]
}
path "database/creds/htx-mathcup-admin-role-v1" {
  capabilities = ["read","update"]
}

path "sys/leases/renew" {
  capabilities = ["update"]
}

path "sys/leases/lookup" {
  capabilities = ["update"]
}

path "sys/leases/revoke" {
  capabilities = ["update"]
}

path "sys/leases/revoke-prefix/*" {
  capabilities = ["update"]
}

path "auth/token/lookup-self" {
  capabilities = ["read"]
}

path "auth/token/renew-self" {
  capabilities = ["update"]
}


htx-pressure-role-policy-v0

path "database/creds/htx-pressure-mathcup-pay-role-v0" {
  capabilities = ["read"]
}
path "database/creds/htx-pressure-mathcup-pay-slave-role-v0" {
  capabilities = ["read"]
}
path "database/creds/htx-pressure-mathcup-admin-role-v0" {
  capabilities = ["read"]
}

path "sys/leases/renew" {
  capabilities = ["update"]
}

path "sys/leases/lookup" {
  capabilities = ["update"]
}

path "sys/leases/revoke" {
  capabilities = ["update"]
}

path "sys/leases/revoke-prefix/*" {
  capabilities = ["update"]
}

path "auth/token/lookup-self" {
  capabilities = ["read"]
}

path "auth/token/renew-self" {
  capabilities = ["update"]
}

