path "database/creds/tx-tyadmin-role-v1" {
  capabilities = ["read","update"]
}
path "database/creds/tx-typayv2-role-v1" {
  capabilities = ["read","update"]
}
path "database/creds/tx-typayv2slave-role-v1" {
  capabilities = ["read","update"]
}
path "database/creds/tx-tybusinessadmin-role-v1" {
  capabilities = ["read","update"]
}
path "database/creds/tx-tymerchantadmin-role-v1" {
  capabilities = ["read","update"]
}
path "database/creds/tx-tysupplieradmin-role-v1" {
  capabilities = ["read","update"]
}
path "database/creds/tx-tysupplieradminslave-role-v1" {
  capabilities = ["read","update"]
}

path "sys/leases/renew" {
  capabilities = ["update"]
}

path "sys/leases/lookup" {
  capabilities = ["update"]
}

path "sys/leases/revoke" {
  capabilities = ["update"]
}

path "sys/leases/revoke-prefix/*" {
  capabilities = ["update"]
}

path "auth/token/lookup-self" {
  capabilities = ["read"]
}

path "auth/token/renew-self" {
  capabilities = ["update"]
}

path "sys/capabilities-self" {
  capabilities = ["update"]
}






path "database/creds/tx-pressure-tyadmin-role-v0" {
  capabilities = ["read"]
}
path "database/creds/tx-pressure-tymerchantadmin-role-v0" {
  capabilities = ["read"]
}
path "database/creds/tx-pressure-typayv2-role-v0" {
  capabilities = ["read"]
}
path "database/creds/tx-pressure-typayv2slave-role-v0" {
  capabilities = ["read"]
}
path "database/creds/tx-pressure-tysupplieradmin-role-v0" {
  capabilities = ["read"]
}
path "database/creds/tx-pressure-tybusinessadmin-role-v0" {
  capabilities = ["read"]
}
path "database/creds/tx-pressure-tysupplieradminslave-role-v0" {
  capabilities = ["read"]
}

path "sys/leases/renew" {
  capabilities = ["update"]
}

path "sys/leases/lookup" {
  capabilities = ["update"]
}

path "sys/leases/revoke" {
  capabilities = ["update"]
}

path "sys/leases/revoke-prefix/*" {
  capabilities = ["update"]
}

path "auth/token/lookup-self" {
  capabilities = ["read"]
}

path "auth/token/renew-self" {
  capabilities = ["update"]
}
