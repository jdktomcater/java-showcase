# ===== 1) 读取动态数据库账号（你的核心需求）=====
path "database/creds/tx-fat-general-tyadmin-role-v0" {
  capabilities = ["read","update"]
}
path "database/creds/tx-fat-general-typayv2-role-v0" {
  capabilities = ["read","update"]
}
path "database/creds/tx-fat-general-typayv2slave-role-v0" {
  capabilities = ["read","update"]
}
path "database/creds/tx-fat-general-tysupplieradmin-role-v0" {
  capabilities = ["read","update"]
}
path "database/creds/tx-fat-general-tybusinessadmin-role-v0" {
  capabilities = ["read","update"]
}

# ===== 2) Lease 续租 / 查询 / 回收（Spring Vault RENEW 常用）=====
path "sys/leases/renew" {
  capabilities = ["update"]
}

path "sys/leases/lookup" {
  capabilities = ["update"]
}

path "sys/leases/revoke" {
  capabilities = ["update"]
}

path "sys/leases/revoke-prefix/*" {
  capabilities = ["update"]
}

# ===== 3) Token 自检 / 续租（很多客户端启动时会调用）=====
path "auth/token/lookup-self" {
  capabilities = ["read"]
}

path "auth/token/renew-self" {
  capabilities = ["update"]
}

# ===== 4) 能力自检（有些 SDK 会调用，缺了可能报权限但不影响读库账号）=====
path "sys/capabilities-self" {
  capabilities = ["update"]
}
