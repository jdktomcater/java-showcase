@echo off
setlocal

REM ======= 配置区 =======
set "VAULT_ADDR=https://txdev-vault.qwasn.com"
set "VAULT_TOKEN=hvs.pER0xhc85jcsKkVLr3oe0UxE"
vault token lookup
vault login "%VAULT_TOKEN%"
REM ======================

